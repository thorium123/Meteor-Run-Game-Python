import pygame
import random
from pygame import mixer
import os 
import math
import time
import asyncio

# Initialize Pygame
pygame.init()
mixer.init()

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# Object Settings
object_width = 50
object_height = 50
fall_speed = 5

### Load music

# Find dir running in to locate files
mydir = os.path.dirname(os.path.realpath(__file__))

# Try/Except block in case music file is missing, prevents crash
try:
    mixer.music.load(fr'{mydir}/Music/tune_1.ogg')
    mixer.music.set_volume(0.03)
    mixer.music.play(loops=-1)
except pygame.error:
    print("Music file not found, running without music.")

# Screen dimensions and flags
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 800

flags = pygame.RESIZABLE | pygame.SCALED

# Create the screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), flags)
pygame.display.set_caption("Meteor Run")

# Player settings
player_width = 100
player_height = 100
player_speed = 5
jump_height = 30
gravity = 1
ground_level = SCREEN_HEIGHT - player_height

# --- LOAD IMAGES ---
# Note: Background loading is moved to the Class below

player_image_left = pygame.image.load(fr'{mydir}/Images/Player-Left.png') 
player_image_left = pygame.transform.scale(player_image_left, (player_width, player_height))

player_image_right = pygame.image.load(fr'{mydir}/Images/Player-Right.png') 
player_image_right = pygame.transform.scale(player_image_right, (player_width, player_height))

player_image_default = pygame.image.load(fr'{mydir}/Images/Player.png') 
player_image_default = pygame.transform.scale(player_image_default, (player_width, player_height))

player_image = player_image_default  # Default image

meteor_image = pygame.image.load(fr'{mydir}/Images/Meteor.png')
meteor_image = pygame.transform.scale(meteor_image, (object_width, object_height))

cheese_image = pygame.image.load(fr'{mydir}/Images/Cheese.png') 
cheese_image = pygame.transform.scale(cheese_image, (object_width, object_height))

b_imgs = [pygame.image.load(fr'{mydir}/Images/Bullet-Red.png'), pygame.image.load(fr'{mydir}/Images/Bullet-Green.png')] 

gem_1_image = pygame.image.load(fr'{mydir}/Images/Gem-1.png')
gem_1_image = pygame.transform.scale(gem_1_image, (object_width,object_height))

gem_2_image = pygame.image.load(fr'{mydir}/Images/Gem-2.png')
gem_2_image = pygame.transform.scale(gem_2_image, (object_width,object_height))


starting_screen_image = pygame.image.load(fr"{mydir}/Images/Starting-Screen-Image.png")
starting_screen_image = pygame.transform.scale(starting_screen_image, (SCREEN_WIDTH, SCREEN_HEIGHT))

you_win_two_options = pygame.image.load(fr"{mydir}/Images/You-Win-Two-Options.png")
you_win_two_options = pygame.transform.scale(you_win_two_options,(SCREEN_WIDTH,SCREEN_HEIGHT))

game_over_two_options = pygame.image.load(fr"{mydir}/Images/Game-Over-Two-Options.png")
game_over_two_options = pygame.transform.scale(game_over_two_options,(SCREEN_WIDTH,SCREEN_HEIGHT))


background_image = pygame.image.load(fr"{mydir}/Images/Background.png")
background_image = pygame.transform.scale(background_image, (SCREEN_WIDTH, SCREEN_HEIGHT)) 


# --- NEW SCROLLING BACKGROUND CLASS ---
class ScrollingBackground:
    def __init__(self, screen_width, screen_height, image_path, speed):
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.speed = speed 
        self.speed -= 3
        self.scroll = 0

        # Load and Scale Image
        self.bg_image = pygame.image.load(image_path).convert()
        self.bg_image = pygame.transform.scale(self.bg_image, (screen_width, screen_height))
        
        # Calculate how many tiles we need
        self.bg_height = self.bg_image.get_height()
        self.tiles = math.ceil(screen_height / self.bg_height) + 1

    def update(self):
        # Scroll moves DOWN (positive speed)
        self.scroll += self.speed

        # Reset scroll if it exceeds the image height
        if abs(self.scroll) > self.bg_height:
            self.scroll = 0

    def draw(self, screen):
        # Draw the background tiles
        # range(-1, tiles) ensures we draw the tile entering from the top
        for i in range(-1, self.tiles):
            y = i * self.bg_height + self.scroll
            screen.blit(self.bg_image, (0, y))

# --- CLASSES ---
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = player_image_default
        self.rect = self.image.get_rect(center=(SCREEN_WIDTH // 2, ground_level))
        self.speed = player_speed
        self.jump_speed = jump_height
        self.gravity = gravity
        self.vel_y = 0
        self.jumping = False
        self.lives = 10
        self.gem_count = 0

    def move(self):
        keys = pygame.key.get_pressed()
        if (keys[pygame.K_a] or keys[pygame.K_LEFT]) and self.rect.left > 0:
            self.rect.x -= self.speed
            self.image = player_image_left 
        elif (keys[pygame.K_d] or keys[pygame.K_RIGHT]) and self.rect.right < SCREEN_WIDTH:
            self.rect.x += self.speed
            self.image = player_image_right 
        else:
            self.image = player_image_default 

    def jump(self):
        keys = pygame.key.get_pressed()
        if (keys[pygame.K_w] or keys[pygame.K_UP]) and not self.jumping:  # Add: and not self.jumping
            self.jumping = True
            self.vel_y = -self.jump_speed

    def apply_gravity(self):
        if self.jumping:
            self.vel_y += self.gravity
            self.rect.y += self.vel_y
            if self.rect.bottom >= ground_level:
                self.rect.bottom = ground_level
                self.jumping = False

    def update(self):
        self.move()
        self.jump()
        self.apply_gravity()

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = random.choice(b_imgs)
        self.image = pygame.transform.scale(self.image, (20, 30))
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = 10

    def update(self):
        self.rect.y -= self.speed
        if self.rect.bottom < 0:
            self.kill()

class Meteor(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = meteor_image
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = fall_speed
        self.transformed = False
        self.gem = False
        self.special_gem = False

    def update(self):
        self.rect.y += self.speed
        if self.rect.top > SCREEN_HEIGHT:
            self.reset()

    def transform_to_cheese(self):
        self.image = cheese_image
        self.transformed = True

    def transform_to_gem(self):
        center = self.rect.center
        self.image = choice([gem_1_image,gem_2_image],[0.9,0.1])
        self.rect = self.image.get_rect(center=center)
        if self.image == gem_2_image:
            self.special_gem = True
        else: 
            self.gem = True

    def reset(self):
        self.image = meteor_image
        self.rect = self.image.get_rect()  # Rebuild rect as 50x50
        self.rect.bottom = random.randint(-SCREEN_HEIGHT // 2,0)
        self.rect.x = random.randint(0, SCREEN_WIDTH - object_width)
        self.transformed = False
        self.gem = False
        self.special_gem = False

class paused(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x 
        self.y = y
        font = pygame.font.SysFont(None, 72)
        paused_text = font.render('PAUSED', True, (255,255,255))
        self.image = paused_text
        self.rect = self.image.get_rect(center=(self.x, self.y))
        mixer.music.pause()
        screen.blit(self.image, self.rect)

# --- SETUP OBJECTS ---
meteors = pygame.sprite.Group()
for _ in range(10):
    meteor = Meteor(random.randint(0, SCREEN_WIDTH - object_width), random.randint(-SCREEN_HEIGHT // 2, 0))
    meteors.add(meteor)

# Initialize Background Object
# Make sure "Images/Background.png" exists!
scrolling_bg = ScrollingBackground(SCREEN_WIDTH, SCREEN_HEIGHT, fr"{mydir}/Images/Background.png", speed=5)

def lives_to_words(lives):
    words = {
        12: "12 Lives", 11: "11 Lives", 10: "10 Lives", 9: "9 Lives", 8: "8 Lives", 7: "7 Lives", 6: "6 Lives",
        5: "5 Lives", 4: "4 Lives", 3: "3 Lives", 2: "2 Lives", 1: "1 Life", 0: "0 Lives"
    }
    if player.lives <= 0:
        player.lives = 0  # Clamp before drawing
        run = False
    return words.get(lives, str(lives))

def draw_lives_in_words(screen, lives):
    font = pygame.font.SysFont(None, 36)
    lives_text = font.render(f'Lives: {lives_to_words(lives)}', True, WHITE)
    screen.blit(lives_text, (10, 10))



def draw_gem_count_in_words(screen, gem_count):
    font = pygame.font.SysFont(None, 36)
    gem_count_text = font.render(f"Gem Count: {gem_count}", True, WHITE)
    screen.blit(gem_count_text, (200,10))

def starting_screen():
   starting_screen_image.draw(screen) 

def choice(sample,weights):
    chosen = random.choices(sample,weights=weights,k=1)
    return chosen[0]

def reset():
    player.lives = 10
    player.gem_count = 0
    player.rect.center = (SCREEN_WIDTH // 2, ground_level)
    pause_game = False
    bullets.empty()
    for meteor in meteors:
        meteor.reset()
    mixer.music.load(fr"{mydir}/Music/tune_1.ogg")
    mixer.music.set_volume(0.03)
    mixer.music.play(loops=-1)

# --- MAIN LOOP ---
clock = pygame.time.Clock()
player = Player()
all_sprites = pygame.sprite.Group()
bullets = pygame.sprite.Group()
pause_game = False

all_sprites.add(player)
all_sprites.add(meteors)

starting_screen = True
you_win = False
music = False
run = True
game = True
mixer.music.pause()
async def main():
    global game, meteor, music, pause_game, run, starting_screen, you_win
    while run:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    pause_game = not pause_game
                elif event.key ==  pygame.K_q:
                    run = False
                elif event.key == pygame.K_s or event.key == pygame.K_DOWN:
                    bullet = Bullet(player.rect.centerx, player.rect.top)
                    all_sprites.add(bullet)
                    bullets.add(bullet)
                elif event.key ==  pygame.K_q:
                    run = False             
                elif event.key == pygame.K_RETURN and starting_screen == True:
                        starting_screen = False 
                elif event.key == pygame.K_RETURN and (game == False or you_win == True):
                    reset()
                    game = True
                    you_win = False

            if event.type == pygame.QUIT:
                run = False
 


        if starting_screen:
        #starting_screen()
            screen.blit(background_image, (0,0))
            screen.blit(starting_screen_image, (0,0))
            pygame.display.flip()
        elif you_win:
            await asyncio.sleep(0.3)
            screen.blit(background_image, (0,0))
            screen.blit(you_win_two_options, (0,0))
            pygame.display.flip()
            if music:
                mixer.music.pause()
                await asyncio.sleep(0.3)
                mixer.music.fadeout(2)
                mixer.music.load(fr"{mydir}/Music/you-win.ogg")
                mixer.music.play(loops=0)

            music = False

        elif game == True:
            if not pause_game:
                mixer.music.unpause()
                # 1. Logic Updates
                scrolling_bg.update()
                all_sprites.update()

                # Collisions
                collisions = pygame.sprite.groupcollide(bullets, meteors, True, False)
                for bullet, hit_meteors in collisions.items():
                    for meteor in hit_meteors:
                        if player.lives in (10, 12):
                            meteor.transform_to_gem()
                        else:
                            meteor.transform_to_cheese()

                for meteor in meteors:
                    if pygame.sprite.collide_rect(player, meteor):
                        if meteor.transformed:
                            if player.lives == 12:
                                meteor.reset()
                            else: 
                                player.lives = min(player.lives + 1, 10)
                                meteor.reset()
                        elif meteor.gem:
                            player.gem_count += 1
                            meteor.reset()
                        elif meteor.special_gem:
                            player.lives = min(player.lives + 2, 12)
                            meteor.reset()

                        else:
                            player.lives -= 2
                            meteor.reset()

                if player.lives <= 0:
                    game = False

                if player.gem_count >= 10:      # set to 30 for the real game
                    you_win = True
                    music = True

                # 3. Drawing
                scrolling_bg.draw(screen)
                all_sprites.draw(screen)
                draw_lives_in_words(screen, player.lives)
                draw_gem_count_in_words(screen, player.gem_count)
            elif pause_game:
                paused(SCREEN_WIDTH/2, SCREEN_HEIGHT/2)

            pygame.display.flip()
            clock.tick(60)

        elif game == False:
            await asyncio.sleep(0.3)
            screen.blit(background_image, (0,0))
            screen.blit(game_over_two_options, (0,0))
            pygame.display.flip()
            mixer.music.pause()
        await asyncio.sleep(0)


    pygame.quit()


asyncio.run(main())
